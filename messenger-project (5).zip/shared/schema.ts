
import { pgTable, text, serial, integer, boolean, timestamp, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  displayName: text("display_name"),
  bio: text("bio").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chats = pgTable("chats", {
  id: serial("id").primaryKey(),
  name: text("name"),
  is_group: boolean("is_group").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chatParticipants = pgTable("chat_participants", {
  id: serial("id").primaryKey(),
  chatId: integer("chatId").notNull().references(() => chats.id),
  userId: integer("userId").notNull().references(() => users.id),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  chatId: integer("chatId").notNull().references(() => chats.id),
  senderId: integer("senderId").notNull().references(() => users.id),
  content: text("content").notNull(),
  sentAt: timestamp("sent_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  displayName: true,
  bio: true,
});

export const insertChatSchema = createInsertSchema(chats).pick({
  name: true,
  isGroup: true,
});

export const insertChatParticipantSchema = createInsertSchema(chatParticipants).pick({
  chatId: true,
  userId: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  chatId: true,
  senderId: true,
  content: true,
});

// Registration schemas
export const registerStep1Schema = z.object({
  email: z.string().email("Необходимо указать корректный email"),
  password: z.string().min(6, "Пароль должен быть не менее 6 символов"),
});

export const registerStep2Schema = z.object({
  displayName: z.string().min(2, "Имя должно быть не менее 2 символов"),
  username: z.string().min(3, "Имя пользователя должно быть не менее 3 символов")
    .max(30, "Имя пользователя должно быть не более 30 символов")
    .regex(/^[a-zA-Z0-9_]+$/, "Имя пользователя может содержать только буквы, цифры и _"),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertChat = z.infer<typeof insertChatSchema>;
export type InsertChatParticipant = z.infer<typeof insertChatParticipantSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type User = typeof users.$inferSelect;
export type Chat = typeof chats.$inferSelect;
export type ChatParticipant = typeof chatParticipants.$inferSelect;
export type Message = typeof messages.$inferSelect;

export type RegisterStep1 = z.infer<typeof registerStep1Schema>;
export type RegisterStep2 = z.infer<typeof registerStep2Schema>;
export type RegisterComplete = RegisterStep1 & RegisterStep2;

// User with select fields for client
export type UserClient = Omit<User, "password">;
