import { users, type User, type InsertUser, messages, type Message, type InsertMessage, chats, type Chat, type InsertChat, chatParticipants, type ChatParticipant, type InsertChatParticipant } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import connectPg from "connect-pg-simple";
import { eq, and, or, like, desc } from "drizzle-orm";
import { sql } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// User with omitted password field for client
type SafeUser = Omit<User, "password">;

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getSafeUser(id: number): Promise<SafeUser | undefined>;
  searchUsers(query: string): Promise<SafeUser[]>;
  
  // Chat methods
  createChat(chat: InsertChat): Promise<Chat>;
  getChat(id: number): Promise<Chat | undefined>;
  getUserChats(userId: number): Promise<{ chat: Chat; lastMessage?: Message; unreadCount?: number }[]>;
  
  // Chat participants methods
  addChatParticipant(participant: InsertChatParticipant): Promise<ChatParticipant>;
  getChatParticipants(chatId: number): Promise<User[]>;
  isChatParticipant(chatId: number, userId: number): Promise<boolean>;
  
  // Messages methods
  createMessage(message: InsertMessage): Promise<Message>;
  getChatMessages(chatId: number): Promise<Message[]>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chats: Map<number, Chat>;
  private chatParticipants: Map<number, ChatParticipant>;
  private messages: Map<number, Message>;
  currentUserId: number;
  currentChatId: number;
  currentChatParticipantId: number;
  currentMessageId: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.chats = new Map();
    this.chatParticipants = new Map();
    this.messages = new Map();
    this.currentUserId = 1;
    this.currentChatId = 1;
    this.currentChatParticipantId = 1;
    this.currentMessageId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  async getSafeUser(id: number): Promise<SafeUser | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password, ...safeUser } = user;
    return safeUser;
  }

  async searchUsers(query: string): Promise<SafeUser[]> {
    if (!query || query.trim() === '') return [];
    
    const lowercaseQuery = query.toLowerCase();
    const matchedUsers = Array.from(this.users.values()).filter(
      (user) => 
        user.username.toLowerCase().includes(lowercaseQuery) ||
        user.displayName.toLowerCase().includes(lowercaseQuery)
    );
    
    return matchedUsers.map(user => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { password, ...safeUser } = user;
      return safeUser;
    });
  }

  // Chat methods
  async createChat(insertChat: InsertChat): Promise<Chat> {
    const id = this.currentChatId++;
    const now = new Date();
    const chat: Chat = { ...insertChat, id, createdAt: now };
    this.chats.set(id, chat);
    return chat;
  }

  async getChat(id: number): Promise<Chat | undefined> {
    return this.chats.get(id);
  }

  async getUserChats(userId: number): Promise<{ chat: Chat; lastMessage?: Message; unreadCount?: number }[]> {
    // Get chat IDs where the user is a participant
    const participantEntries = Array.from(this.chatParticipants.values())
      .filter(participant => participant.userId === userId)
      .map(participant => participant.chatId);
    
    // Get chats for these IDs
    const userChats = await Promise.all(
      participantEntries.map(async (chatId) => {
        const chat = await this.getChat(chatId);
        if (!chat) return null;
        
        // Get all messages for this chat
        const chatMessages = Array.from(this.messages.values())
          .filter(message => message.chatId === chatId)
          .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
        
        const lastMessage = chatMessages.length > 0 ? chatMessages[0] : undefined;
        
        return {
          chat,
          lastMessage,
          unreadCount: 0 // In a real app, we would track read status
        };
      })
    );
    
    return userChats.filter((chat): chat is { chat: Chat; lastMessage?: Message; unreadCount?: number } => chat !== null);
  }

  // Chat participants methods
  async addChatParticipant(insertParticipant: InsertChatParticipant): Promise<ChatParticipant> {
    const id = this.currentChatParticipantId++;
    const now = new Date();
    const participant: ChatParticipant = { ...insertParticipant, id, joinedAt: now };
    this.chatParticipants.set(id, participant);
    return participant;
  }

  async getChatParticipants(chatId: number): Promise<User[]> {
    const participantIds = Array.from(this.chatParticipants.values())
      .filter(participant => participant.chatId === chatId)
      .map(participant => participant.userId);
    
    const participants = await Promise.all(
      participantIds.map(async (userId) => {
        const user = await this.getUser(userId);
        return user;
      })
    );
    
    return participants.filter((user): user is User => user !== undefined);
  }

  async isChatParticipant(chatId: number, userId: number): Promise<boolean> {
    return Array.from(this.chatParticipants.values()).some(
      participant => participant.chatId === chatId && participant.userId === userId
    );
  }

  // Message methods
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const now = new Date();
    const message: Message = { ...insertMessage, id, sentAt: now };
    this.messages.set(id, message);
    return message;
  }

  async getChatMessages(chatId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.chatId === chatId)
      .sort((a, b) => new Date(a.sentAt).getTime() - new Date(b.sentAt).getTime());
  }
}

// Добавляем класс PostgreSQL Storage
export class DatabaseStorage implements IStorage {
  db: any;
  sessionStore: session.SessionStore;
  
  constructor() {
    // Настраиваем подключение к базе данных
    const queryClient = postgres(process.env.DATABASE_URL || '');
    this.db = drizzle(queryClient);
    
    // Настраиваем хранилище для сессий
    this.sessionStore = new PostgresSessionStore({
      conObject: {
        connectionString: process.env.DATABASE_URL,
      },
      createTableIfMissing: true
    });
  }
  
  // Методы для работы с пользователями
  async getUser(id: number): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username));
    return result[0];
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.email, email));
    return result[0];
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    // Обновим для работы с подготовленными запросами Drizzle
    const [user] = await this.db.insert(users).values({
      username: insertUser.username,
      email: insertUser.email,
      password: insertUser.password,
      display_name: insertUser.displayName,
      bio: insertUser.bio || "",
      created_at: new Date()
    }).returning();
    
    return user;
  }
  
  async getSafeUser(id: number): Promise<SafeUser | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const { password, ...safeUser } = user;
    return safeUser;
  }
  
  async searchUsers(query: string): Promise<SafeUser[]> {
    if (!query || query.trim() === '') return [];
    
    const searchTerm = `%${query.toLowerCase()}%`;
    
    // Используем ORM запрос вместо SQL
    const result = await this.db
      .select()
      .from(users)
      .where(
        or(
          like(sql`LOWER(${users.username})`, searchTerm),
          like(sql`LOWER(${users.displayName})`, searchTerm)
        )
      );
    
    return result.map(user => {
      const { password, ...safeUser } = user;
      return safeUser;
    });
  }
  
  // Методы для работы с чатами
  async createChat(insertChat: InsertChat): Promise<Chat> {
    // Используем подготовленные запросы Drizzle с точными именами полей
    const [chat] = await this.db.insert(chats).values({
      name: insertChat.name || null,
      created_at: new Date()
    }).returning();
    
    return chat;
  }
  
  async getChat(id: number): Promise<Chat | undefined> {
    const result = await this.db.select().from(chats).where(eq(chats.id, id));
    return result[0];
  }
  
  async getUserChats(userId: number): Promise<{ chat: Chat; lastMessage?: Message; unreadCount?: number }[]> {
    // Получаем все чаты, в которых участвует пользователь
    const userChatsResult = await this.db
      .select({ chatId: chatParticipants.chatId })
      .from(chatParticipants)
      .where(eq(chatParticipants.userId, userId));
      
    const chatIds = userChatsResult.map(result => result.chatId);
    
    if (chatIds.length === 0) {
      return [];
    }
    
    // Получаем информацию о чатах
    const chatsInfo = await Promise.all(
      chatIds.map(async (chatId) => {
        // Получаем информацию о чате
        const chatResults = await this.db
          .select()
          .from(chats)
          .where(eq(chats.id, chatId));
        const chat = chatResults[0];
        
        // Получаем последнее сообщение
        const lastMessageResults = await this.db
          .select()
          .from(messages)
          .where(eq(messages.chatId, chatId))
          .orderBy(desc(messages.sent_at))
          .limit(1);
        const lastMessage = lastMessageResults[0];
          
        // Для простоты считаем все сообщения от других пользователей непрочитанными
        const countResults = await this.db
          .select({ count: sql<number>`count(*)` })
          .from(messages)
          .where(
            and(
              eq(messages.chatId, chatId),
              sql`${messages.senderId} <> ${userId}`
            )
          );
        const unreadCount = Number(countResults[0].count) || 0;
          
        return {
          chat,
          lastMessage,
          unreadCount
        };
      })
    );
    
    return chatsInfo;
  }
  
  // Методы для работы с участниками чатов
  async addChatParticipant(insertParticipant: InsertChatParticipant): Promise<ChatParticipant> {
    const [participant] = await this.db
      .insert(chatParticipants)
      .values({
        chatId: insertParticipant.chatId,
        userId: insertParticipant.userId,
        joined_at: new Date()
      })
      .returning();
    
    return participant;
  }
  
  async getChatParticipants(chatId: number): Promise<User[]> {
    const participantUsers = await this.db
      .select({ user: users })
      .from(chatParticipants)
      .where(eq(chatParticipants.chatId, chatId))
      .innerJoin(users, eq(chatParticipants.userId, users.id));
    
    return participantUsers.map(({ user }) => user);
  }
  
  async isChatParticipant(chatId: number, userId: number): Promise<boolean> {
    const [result] = await this.db
      .select({ count: sql<number>`count(*)` })
      .from(chatParticipants)
      .where(
        and(
          eq(chatParticipants.chatId, chatId),
          eq(chatParticipants.userId, userId)
        )
      );
      
    return Number(result.count) > 0;
  }
  
  // Методы для работы с сообщениями
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await this.db
      .insert(messages)
      .values({
        chatId: insertMessage.chatId,
        senderId: insertMessage.senderId,
        content: insertMessage.content,
        sent_at: new Date()
      })
      .returning();
      
    return message;
  }
  
  async getChatMessages(chatId: number): Promise<Message[]> {
    const result = await this.db
      .select()
      .from(messages)
      .where(eq(messages.chatId, chatId))
      .orderBy(messages.sent_at);
      
    return result;
  }
}

// Используем PostgreSQL если переменная окружения DATABASE_URL установлена, иначе MemStorage
export const storage = process.env.DATABASE_URL 
  ? new DatabaseStorage() 
  : new MemStorage();
