import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { setupWebSockets } from "./websocket";
import { z } from "zod";
import archiver from "archiver";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup Authentication
  setupAuth(app);

  const httpServer = createServer(app);

  // Setup WebSockets for real-time messaging
  setupWebSockets(httpServer, storage);

  // API Routes
  // Search users
  app.get("/api/users/search", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Не авторизован" });
    }

    const query = req.query.q as string;
    if (!query) {
      return res.status(400).json({ message: "Параметр поиска отсутствует" });
    }

    try {
      const users = await storage.searchUsers(query);
      
      // Don't include the current user in results
      const filteredUsers = users.filter(user => user.id !== req.user?.id);
      
      res.json(filteredUsers);
    } catch (error) {
      console.error("Error searching users:", error);
      res.status(500).json({ message: "Ошибка поиска пользователей" });
    }
  });

  // Get user chats
  app.get("/api/chats", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Не авторизован" });
    }

    try {
      const chats = await storage.getUserChats(req.user.id);
      
      // Enhance chats with participant information
      const enhancedChats = await Promise.all(
        chats.map(async (chatInfo) => {
          const participants = await storage.getChatParticipants(chatInfo.chat.id);
          const safeParticipants = participants.map(participant => {
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            const { password, ...safeUser } = participant;
            return safeUser;
          });
          
          return {
            ...chatInfo,
            participants: safeParticipants
          };
        })
      );
      
      res.json(enhancedChats);
    } catch (error) {
      console.error("Error fetching chats:", error);
      res.status(500).json({ message: "Ошибка при получении чатов" });
    }
  });

  // Get chat messages
  app.get("/api/chats/:chatId/messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Не авторизован" });
    }

    const chatId = parseInt(req.params.chatId);
    if (isNaN(chatId)) {
      return res.status(400).json({ message: "Неверный ID чата" });
    }

    try {
      // Check if user is a participant in this chat
      const isParticipant = await storage.isChatParticipant(chatId, req.user.id);
      if (!isParticipant) {
        return res.status(403).json({ message: "Доступ запрещен" });
      }

      const messages = await storage.getChatMessages(chatId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Ошибка при получении сообщений" });
    }
  });

  // Create new chat
  app.post("/api/chats", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Не авторизован" });
    }

    try {
      const schema = z.object({
        name: z.string().optional(),
        participantId: z.number().int().positive(),
        isGroup: z.boolean().default(false),
      });

      const validation = schema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Неверные параметры", errors: validation.error.errors });
      }

      const { name, participantId, isGroup } = validation.data;

      // Check if chat already exists (for 1-on-1 chats)
      if (!isGroup) {
        const userChats = await storage.getUserChats(req.user.id);
        
        for (const chatInfo of userChats) {
          if (chatInfo.chat.isGroup) continue;
          
          const participants = await storage.getChatParticipants(chatInfo.chat.id);
          if (participants.length === 2 && participants.some(p => p.id === participantId)) {
            // Chat already exists, return it
            return res.status(200).json(chatInfo.chat);
          }
        }
      }

      // Create new chat
      const chatName = name || "";
      const chat = await storage.createChat({ name: chatName, isGroup });

      // Add participants
      await storage.addChatParticipant({ chatId: chat.id, userId: req.user.id });
      await storage.addChatParticipant({ chatId: chat.id, userId: participantId });

      // If it's a new chat with support (id=1), send a welcome message
      if (participantId === 1) {
        await storage.createMessage({
          chatId: chat.id,
          senderId: 1,
          content: "Ваш аккаунт был зарегистрирован! Добро пожаловать в Detox!"
        });
      }

      res.status(201).json(chat);
    } catch (error) {
      console.error("Error creating chat:", error);
      res.status(500).json({ message: "Ошибка при создании чата" });
    }
  });

  // Send message
  app.post("/api/chats/:chatId/messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Не авторизован" });
    }

    const chatId = parseInt(req.params.chatId);
    if (isNaN(chatId)) {
      return res.status(400).json({ message: "Неверный ID чата" });
    }

    try {
      const schema = z.object({
        content: z.string().min(1).max(5000),
      });

      const validation = schema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Неверные параметры", errors: validation.error.errors });
      }

      const { content } = validation.data;

      // Check if user is a participant in this chat
      const isParticipant = await storage.isChatParticipant(chatId, req.user.id);
      if (!isParticipant) {
        return res.status(403).json({ message: "Доступ запрещен" });
      }

      const message = await storage.createMessage({
        chatId,
        senderId: req.user.id,
        content,
      });

      res.status(201).json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: "Ошибка при отправке сообщения" });
    }
  });
  
  // Get user profile
  app.get("/api/users/:userId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Не авторизован" });
    }

    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Неверный ID пользователя" });
    }

    try {
      const user = await storage.getSafeUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }

      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Ошибка при получении профиля пользователя" });
    }
  });
  
  // Update user profile
  app.patch("/api/users/:userId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Не авторизован" });
    }

    const userId = parseInt(req.params.userId);
    if (isNaN(userId) || userId !== req.user.id) {
      return res.status(403).json({ message: "Доступ запрещен" });
    }

    try {
      const schema = z.object({
        displayName: z.string().min(2).max(50),
        bio: z.string().max(200).optional(),
      });

      const validation = schema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Неверные параметры", errors: validation.error.errors });
      }

      // For now, only allow updating displayName and bio
      const { displayName, bio } = validation.data;
      
      // In a real app, this would update the database
      // For our in-memory storage, we need to get the user and update fields
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }
      
      // Update fields
      user.displayName = displayName;
      if (bio !== undefined) {
        user.bio = bio;
      }
      
      // Return safe user (without password)
      const safeUser = await storage.getSafeUser(userId);
      res.json(safeUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Ошибка при обновлении профиля" });
    }
  });

  // Download project archive
  app.get("/api/download-archive", async (req, res) => {
    const archive = archiver("zip", {
      zlib: { level: 9 }
    });

    res.attachment("messenger-project.zip");
    archive.pipe(res);

    // Add all project files excluding node_modules and other unnecessary directories
    archive.glob("**/*", {
      ignore: [
        'node_modules/**',
        '.git/**',
        'dist/**',
        '.config/**',
        'messenger-project.zip'
      ]
    });

    await archive.finalize();
  });

  return httpServer;
}
