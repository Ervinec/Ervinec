import { Server as HttpServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { IStorage } from "./storage";
import { parse } from "url";

interface ExtendedWebSocket extends WebSocket {
  userId?: number;
  isAlive: boolean;
}

interface WSMessage {
  type: string;
  payload: any;
}

export function setupWebSockets(server: HttpServer, storage: IStorage) {
  const wss = new WebSocketServer({ noServer: true });

  // Store connected clients by userId
  const clients = new Map<number, ExtendedWebSocket[]>();

  // Handle upgrade requests
  server.on("upgrade", (request, socket, head) => {
    const { pathname, query } = parse(request.url || "", true);

    if (pathname === "/ws") {
      wss.handleUpgrade(request, socket, head, (ws) => {
        const extWs = ws as ExtendedWebSocket;
        extWs.isAlive = true;

        // Get the user ID from query parameter
        const userId = parseInt(query.userId as string);
        if (!isNaN(userId)) {
          extWs.userId = userId;
          console.log(`Setting WebSocket userId: ${userId}`);

          // Add client to the map
          if (!clients.has(userId)) {
            clients.set(userId, []);
          }
          clients.get(userId)?.push(extWs);
        } else {
          console.log('WebSocket connected without valid userId');
        }

        wss.emit("connection", extWs, request);
      });
    } else {
      socket.destroy();
    }
  });

  // Handle connections
  wss.on("connection", (ws: ExtendedWebSocket) => {
    console.log(`WebSocket connected for user ${ws.userId}`);

    // Handle heartbeat
    ws.on("pong", () => {
      ws.isAlive = true;
    });

    ws.on("message", async (message) => {
      try {
        const parsedMessage = JSON.parse(message.toString()) as WSMessage;

        switch (parsedMessage.type) {
          case "message":
            handleNewMessage(parsedMessage.payload, ws);
            break;

          case "typing":
            handleTyping(parsedMessage.payload, ws);
            break;

          default:
            console.log(`Unknown message type: ${parsedMessage.type}`);
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    });

    ws.on("close", () => {
      console.log(`WebSocket closed for user ${ws.userId}`);

      // Remove client from the map
      if (ws.userId) {
        const userClients = clients.get(ws.userId) || [];
        const filteredClients = userClients.filter(client => client !== ws);

        if (filteredClients.length === 0) {
          clients.delete(ws.userId);
        } else {
          clients.set(ws.userId, filteredClients);
        }
      }
    });
  });

  // Heartbeat interval to check for dead connections
  const interval = setInterval(() => {
    wss.clients.forEach((ws) => {
      const extWs = ws as ExtendedWebSocket;
      if (extWs.isAlive === false) {
        return ws.terminate();
      }

      extWs.isAlive = false;
      extWs.ping();
    });
  }, 30000);

  wss.on("close", () => {
    clearInterval(interval);
  });

  // Handle new messages
  async function handleNewMessage(payload: any, ws: ExtendedWebSocket) {
    if (!ws.userId) return;

    // Проверяем валидность данных
    if (!payload || !payload.chatId || !payload.content) {
      return sendError(ws, "Некорректные данные сообщения");
    }

    const { chatId, content } = payload;

    try {
      // Validate that the user is in this chat
      const isParticipant = await storage.isChatParticipant(chatId, ws.userId);
      if (!isParticipant) {
        return sendError(ws, "Вы не участник этого чата");
      }

      // Create message in database
      const message = await storage.createMessage({
        chatId,
        senderId: ws.userId,
        content
      });

      // Get chat participants to broadcast message to
      const participants = await storage.getChatParticipants(chatId);

      // Broadcast to all participants
      for (const participant of participants) {
        const userClients = clients.get(participant.id) || [];

        for (const client of userClients) {
          sendMessage(client, {
            type: "new_message",
            payload: message
          });
        }
      }

    } catch (error) {
      console.error("Error handling WebSocket message:", error);
      sendError(ws, "Ошибка при отправке сообщения");
    }
  }

  // Handle typing indicator
  function handleTyping(payload: any, ws: ExtendedWebSocket) {
    if (!ws.userId) return;

    const { chatId, isTyping } = payload;

    storage.isChatParticipant(chatId, ws.userId).then(isParticipant => {
      if (!isParticipant) return;

      // Get chat participants
      storage.getChatParticipants(chatId).then(participants => {
        // Broadcast typing status to all participants except the sender
        for (const participant of participants) {
          if (participant.id === ws.userId) continue;

          const userClients = clients.get(participant.id) || [];

          for (const client of userClients) {
            sendMessage(client, {
              type: "typing",
              payload: {
                chatId,
                userId: ws.userId,
                isTyping
              }
            });
          }
        }
      });
    });
  }

  // Helper function to send messages
  function sendMessage(ws: WebSocket, message: WSMessage) {
    ws.send(JSON.stringify(message));
  }

  // Helper function to send errors
  function sendError(ws: WebSocket, errorMessage: string) {
    sendMessage(ws, {
      type: "error",
      payload: { message: errorMessage }
    });
  }

  return wss;
}