export const APP_NAME = "Detox";
export const APP_SLOGAN = "Быстрый и удобный";

export const COLORS = {
  primary: "#8774E1",
  darkBg: "#17212B",
  darkSecondary: "#232E3C",
  inputBg: "#242F3D",
  lightText: "#FFFFFF",
  secondaryText: "#8A8A8A",
  messageBg: "#2B5278",
  myMessageBg: "#3B6A99",
  divider: "#151F28"
};

export const AVATAR_COLORS = [
  "#8774E1", // Primary
  "#4CAF50", // Green
  "#2196F3", // Blue
  "#FF9800", // Orange
  "#E91E63", // Pink
  "#9C27B0", // Purple
  "#00BCD4", // Cyan
  "#FFEB3B", // Yellow
  "#795548", // Brown
  "#607D8B", // Blue Grey
];

// Get avatar color based on userId
export function getAvatarColor(id: number): string {
  return AVATAR_COLORS[id % AVATAR_COLORS.length];
}

// Get initials from user's display name
export function getInitials(displayName: string): string {
  if (!displayName) return "??";
  
  const parts = displayName.trim().split(/\s+/);
  if (parts.length === 1) {
    return parts[0].substring(0, 2).toUpperCase();
  }
  
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

// Format date to HH:MM
export function formatTime(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
}

// Format date to friendly format (today, yesterday, date)
export function formatDate(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  
  // Today
  if (d.getDate() === now.getDate() && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()) {
    return formatTime(d);
  }
  
  // Yesterday
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (d.getDate() === yesterday.getDate() && d.getMonth() === yesterday.getMonth() && d.getFullYear() === yesterday.getFullYear()) {
    return 'Вчера';
  }
  
  // This week
  const oneWeekAgo = new Date(now);
  oneWeekAgo.setDate(now.getDate() - 7);
  if (d > oneWeekAgo) {
    const days = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
    return days[d.getDay()];
  }
  
  // Older
  return `${d.getDate().toString().padStart(2, '0')}.${(d.getMonth() + 1).toString().padStart(2, '0')}.${d.getFullYear()}`;
}
