import React, { useEffect, useState } from "react";
import { ChevronLeft, Search, Loader2, MessageCircle, UserPlus } from "lucide-react";
import { useChat } from "@/hooks/use-chat";
import { getAvatarColor, getInitials } from "@/lib/constants";
import { useMobile } from "@/hooks/use-mobile";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";

interface SearchResultsProps {
  query: string;
  onQueryChange: (query: string) => void;
  onClose: () => void;
}

const SearchResults: React.FC<SearchResultsProps> = ({ query, onQueryChange, onClose }) => {
  const { searchUsers, createChat, selectChat } = useChat();
  const [results, setResults] = useState<Omit<User, "password">[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isCreatingChat, setIsCreatingChat] = useState<Record<number, boolean>>({});
  const isMobile = useMobile();
  
  // Search users when query changes
  useEffect(() => {
    const fetchUsers = async () => {
      if (query.trim().length < 2) {
        setResults([]);
        return;
      }
      
      setIsSearching(true);
      try {
        const users = await searchUsers(query);
        setResults(users);
      } catch (error) {
        console.error("Error searching users:", error);
      } finally {
        setIsSearching(false);
      }
    };
    
    const debounce = setTimeout(fetchUsers, 300);
    return () => clearTimeout(debounce);
  }, [query, searchUsers]);
  
  const handleCreateChat = async (userId: number) => {
    setIsCreatingChat(prev => ({ ...prev, [userId]: true }));
    
    try {
      const chat = await createChat(userId);
      // Выбираем созданный чат
      selectChat(chat.id);
      // Закрываем поиск и, если на мобильном устройстве, сразу открываем окно чата
      onClose();
    } catch (error) {
      console.error("Error creating chat:", error);
    } finally {
      setIsCreatingChat(prev => ({ ...prev, [userId]: false }));
    }
  };
  
  return (
    <div className="absolute top-0 left-0 w-full h-full flex flex-col bg-[#17212b]">
      <div className="chat-header flex items-center">
        <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-[#182533]/70 mr-2">
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <div className="flex-grow relative">
          <input
            type="text"
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder="Поиск пользователей"
            className="w-full px-4 py-2 rounded bg-[#182533] text-white placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-primary/50"
            autoFocus
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
      </div>

      <div className="flex-grow p-4 overflow-y-auto">
        {isSearching ? (
          <div className="flex justify-center items-center h-20">
            <Loader2 className="h-6 w-6 animate-spin text-white/50" />
          </div>
        ) : results.length > 0 ? (
          <div className="space-y-2">
            {results.map(user => (
              <div 
                key={user.id}
                className="p-3 flex items-center justify-between bg-[#182533]/80 rounded-lg hover:bg-[#182533] transition-colors"
              >
                <div className="flex items-center">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center mr-3 flex-shrink-0 user-avatar"
                    style={{ backgroundColor: getAvatarColor(user.id) }}
                  >
                    <span className="text-white font-medium">{getInitials(user.displayName)}</span>
                  </div>
                  <div>
                    <h3 className="font-medium text-white">{user.displayName}</h3>
                    <p className="text-sm text-gray-400">@{user.username}</p>
                  </div>
                </div>
                <Button
                  onClick={() => handleCreateChat(user.id)}
                  disabled={isCreatingChat[user.id]}
                  className="text-white hover:bg-primary/90"
                >
                  {isCreatingChat[user.id] ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <MessageCircle className="h-4 w-4 mr-2" />
                  )}
                  Написать
                </Button>
              </div>
            ))}
          </div>
        ) : query.trim().length > 1 ? (
          <div className="text-center p-10 flex flex-col items-center justify-center h-full">
            <div className="w-16 h-16 bg-[#253342] rounded-full flex items-center justify-center mb-4">
              <UserPlus className="h-7 w-7 text-gray-400" />
            </div>
            <p className="text-white text-lg mb-2">Пользователи не найдены</p>
            <p className="text-gray-400 text-sm max-w-xs">
              Попробуйте другой поисковый запрос или проверьте правильность написания имени пользователя
            </p>
          </div>
        ) : (
          <div className="text-center p-10 flex flex-col items-center justify-center h-full">
            <div className="w-16 h-16 bg-[#253342] rounded-full flex items-center justify-center mb-4">
              <Search className="h-7 w-7 text-gray-400" />
            </div>
            <p className="text-white text-lg mb-2">Поиск пользователей</p>
            <p className="text-gray-400 text-sm max-w-xs">
              Введите имя пользователя или отображаемое имя для поиска. Минимум 2 символа.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchResults;
