import React, { useEffect, useRef, useState } from "react";
import { ChevronLeft, Paperclip, Send, MoreVertical, User as UserIcon } from "lucide-react";
import { useChat } from "@/hooks/use-chat";
import { useAuth } from "@/hooks/use-auth";
import { getAvatarColor, getInitials } from "@/lib/constants";
import MessageBubble from "./message-bubble";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface ChatWindowProps {
  onBackToChats: () => void;
  isMobile: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ onBackToChats, isMobile }) => {
  const { user } = useAuth();
  const { 
    chats, 
    currentChatId, 
    messages, 
    sendMessage, 
    typingUsers, 
    startTyping, 
    stopTyping 
  } = useChat();
  const [messageInput, setMessageInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Find current chat info
  const currentChat = chats.find(c => c.chat.id === currentChatId);
  
  // Find other participant (for 1-on-1 chats)
  const otherParticipants = currentChat?.participants.filter(p => p.id !== user?.id) || [];
  const otherParticipant = otherParticipants[0];
  
  // Typing users for this chat
  const chatTypingUsers = currentChatId ? typingUsers[currentChatId] || [] : [];
  
  // Display name is either chat name or other participant's name
  const displayName = currentChat?.chat.name || (otherParticipant ? otherParticipant.displayName : "Неизвестный чат");
  
  // For avatar
  const isSupport = otherParticipant?.username === "support";
  const avatarColor = isSupport ? "#8774E1" : otherParticipant ? getAvatarColor(otherParticipant.id) : "#7f7f7f";
  const initials = isSupport ? "" : otherParticipant ? getInitials(otherParticipant.displayName) : "??";
  
  // For navigation
  const [, setLocation] = useLocation();
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  const handleSendMessage = () => {
    if (messageInput.trim()) {
      sendMessage(messageInput);
      setMessageInput("");
    }
  };
  
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessageInput(e.target.value);
    
    // Send typing indication
    if (e.target.value.trim()) {
      startTyping();
    } else {
      stopTyping();
    }
  };
  
  // If no chat is selected
  if (!currentChatId || !currentChat) {
    return (
      <div className="flex-grow flex flex-col items-center justify-center h-full text-white">
        <div className="user-avatar w-20 h-20 mb-6">
          <span className="text-2xl">D</span>
        </div>
        <p className="text-xl mb-3">Выберите чат, чтобы начать общение</p>
        <p className="text-gray-400 text-center max-w-xs">
          Или нажмите на кнопку «+» слева внизу, чтобы начать новый разговор
        </p>
      </div>
    );
  }
  
  return (
    <div className="flex-grow flex flex-col h-full">
      {/* Chat Header */}
      <div className="chat-header flex items-center">
        {isMobile && (
          <Button variant="ghost" size="icon" onClick={onBackToChats} className="text-white mr-2">
            <ChevronLeft className="h-5 w-5" />
          </Button>
        )}
        
        <div 
          className="w-10 h-10 rounded-full flex items-center justify-center mr-3 flex-shrink-0 user-avatar" 
          style={{ backgroundColor: avatarColor }}
        >
          {isSupport ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
          ) : (
            <span className="text-white font-medium">{initials}</span>
          )}
        </div>
        
        <div>
          <h2 className="font-medium text-white">{displayName}</h2>
          <p className="text-xs text-gray-400">
            {chatTypingUsers.length > 0 
              ? <span className="text-primary">{chatTypingUsers.join(', ')} печатает...</span> 
              : 'В сети'}
          </p>
        </div>
        
        <div className="ml-auto flex">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-white hover:bg-[#182533]/70 mr-1"
            onClick={() => otherParticipant && setLocation(`/profile/${otherParticipant.id}`)}
            title="Профиль пользователя"
          >
            <UserIcon className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-white hover:bg-[#182533]/70">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Messages */}
      <div className="flex-grow py-4 px-6 overflow-y-auto">
        <div className="flex flex-col space-y-4 max-w-2xl mx-auto">
          {messages.map((message) => {
            const sender = currentChat.participants.find(p => p.id === message.senderId);
            const isCurrentUser = message.senderId === user?.id;
            
            return (
              <MessageBubble
                key={message.id}
                message={message}
                sender={sender as User}
                isCurrentUser={isCurrentUser}
              />
            );
          })}
          
          {/* For auto-scrolling */}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      {/* Message Input */}
      <div className="chat-input-area">
        <div className="flex items-center max-w-2xl mx-auto">
          <Button variant="ghost" size="icon" className="mr-2 text-gray-400 hover:text-primary hover:bg-[#182533]/70">
            <Paperclip className="h-5 w-5" />
          </Button>
          
          <input
            value={messageInput}
            onChange={handleInputChange}
            onKeyDown={handleKeyPress}
            type="text"
            placeholder="Написать сообщение..."
            className="flex-grow px-4 py-2 rounded-full bg-[#182533] text-white placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-primary/50"
          />
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={handleSendMessage}
            disabled={!messageInput.trim()}
            className={`ml-2 ${messageInput.trim() ? 'text-primary hover:bg-[#182533]/70' : 'text-gray-500'}`}
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
