import React from "react";
import { Message } from "@shared/schema";
import { User } from "@shared/schema";
import { getAvatarColor, getInitials, formatTime } from "@/lib/constants";

interface MessageBubbleProps {
  message: Message;
  sender: User;
  isCurrentUser: boolean;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, sender, isCurrentUser }) => {
  const isSupport = sender?.username === "support";
  const formattedTime = formatTime(message.sentAt);
  
  if (isCurrentUser) {
    return (
      <div className="flex items-start justify-end max-w-xs sm:max-w-md ml-auto group">
        <div 
          className="p-3 rounded-lg bg-[#2b5278] text-white my-message"
        >
          <p>{message.content}</p>
          <span className="block text-right mt-1 text-xs text-[#a0c3e8] group-hover:opacity-100 transition-opacity">{formattedTime}</span>
        </div>
      </div>
    );
  }
  
  // Avatar color and initials
  const avatarColor = isSupport ? "#8774E1" : getAvatarColor(sender.id);
  const initials = isSupport ? "" : getInitials(sender.displayName);
  
  return (
    <div className="flex items-start max-w-xs sm:max-w-md group">
      <div 
        className="w-8 h-8 rounded-full flex items-center justify-center mr-2 flex-shrink-0 user-avatar"
        style={{ backgroundColor: avatarColor }}
      >
        {isSupport ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
          </svg>
        ) : (
          <span className="text-white font-medium text-xs">{initials}</span>
        )}
      </div>
      
      <div 
        className="p-3 bg-[#182533] text-white rounded-lg other-message"
      >
        <p>{message.content}</p>
        <span className="block text-right mt-1 text-xs text-gray-400 group-hover:opacity-100 transition-opacity">{formattedTime}</span>
      </div>
    </div>
  );
};

export default MessageBubble;
