import React, { useState } from "react";
import { Search, Menu, Plus, User as UserIcon, LogOut } from "lucide-react";
import { useChat, ChatWithParticipants } from "@/hooks/use-chat";
import { getAvatarColor, getInitials, formatDate, APP_NAME } from "@/lib/constants";
import { useAuth } from "@/hooks/use-auth";
import { useMobile } from "@/hooks/use-mobile";
import TelegramLogo from "@/components/ui/telegram-logo";
import SearchResults from "./search-results";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

type ChatItemProps = {
  chatInfo: ChatWithParticipants;
  selected: boolean;
  onClick: () => void;
};

const ChatItem: React.FC<ChatItemProps> = ({ chatInfo, selected, onClick }) => {
  const { user } = useAuth();
  
  if (!user) return null;
  
  // Find other participant (for 1-on-1 chats)
  const otherParticipant = chatInfo.participants.find(p => p.id !== user.id);
  
  // Display name is either chat name or other participant's name
  const displayName = chatInfo.chat.name || (otherParticipant ? otherParticipant.displayName : "Неизвестный чат");
  
  // For avatar
  const isSupport = otherParticipant?.username === "support";
  const avatarColor = isSupport ? "#8774E1" : otherParticipant ? getAvatarColor(otherParticipant.id) : "#7f7f7f";
  const initials = isSupport ? "" : otherParticipant ? getInitials(otherParticipant.displayName) : "??";
  
  // Last message preview
  const lastMessageContent = chatInfo.lastMessage?.content || "Нет сообщений";
  const lastMessageTime = chatInfo.lastMessage ? formatDate(chatInfo.lastMessage.sentAt) : "";
  
  return (
    <div 
      className={`p-3 flex items-center cursor-pointer border-b border-[#0e1621]/50 ${
        selected ? "bg-[#2b5278]/20" : "hover:bg-[#182533]"
      }`}
      onClick={onClick}
    >
      <div 
        className="w-12 h-12 rounded-full flex items-center justify-center mr-3 flex-shrink-0 user-avatar"
        style={{ backgroundColor: avatarColor }}
      >
        {isSupport ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
          </svg>
        ) : (
          <span className="text-white font-medium">{initials}</span>
        )}
      </div>
      <div className="flex-grow min-w-0">
        <div className="flex justify-between">
          <h3 className="font-medium text-white truncate">{displayName}</h3>
          <span className="text-xs text-gray-400 ml-2">{lastMessageTime}</span>
        </div>
        <p className="text-gray-400 text-sm truncate">{lastMessageContent}</p>
      </div>
      {chatInfo.unreadCount ? (
        <div className="ml-2 bg-primary rounded-full w-5 h-5 flex items-center justify-center">
          <span className="text-xs text-white">{chatInfo.unreadCount}</span>
        </div>
      ) : null}
    </div>
  );
};

const ChatList: React.FC<{onChatSelect?: () => void}> = ({ onChatSelect }) => {
  const { chats, currentChatId, selectChat } = useChat();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const isMobile = useMobile();
  
  const handleChatClick = (chatId: number) => {
    selectChat(chatId);
    // На мобильных устройствах после выбора чата переходим в окно чата
    if (isMobile && onChatSelect) {
      onChatSelect();
    }
  };
  
  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
  };
  
  if (searchOpen) {
    return (
      <SearchResults 
        query={searchQuery}
        onQueryChange={setSearchQuery}
        onClose={() => setSearchOpen(false)}
      />
    );
  }
  
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-3 chat-header flex items-center justify-between">
        <div className="flex items-center">
          <div 
            className="w-10 h-10 rounded-full flex items-center justify-center mr-3 flex-shrink-0 user-avatar cursor-pointer"
            style={{ backgroundColor: user ? getAvatarColor(user.id) : "#7f7f7f" }}
            onClick={() => setLocation("/profile")}
            title="Мой профиль"
          >
            <span className="text-white font-medium">{user ? getInitials(user.displayName) : "D"}</span>
          </div>
          <h1 className="text-xl font-medium text-white">{APP_NAME}</h1>
        </div>
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setLocation("/profile")} 
            className="text-white hover:bg-[#182533]/70 mr-1"
            title="Мой профиль"
          >
            <UserIcon className="h-5 w-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleLogout} 
            className="text-white hover:bg-[#182533]/70"
            title="Выход"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Search */}
      <div className="px-3 py-2">
        <div className="relative">
          <input
            type="text"
            placeholder="Поиск"
            className="w-full px-4 py-2 rounded bg-[#182533] text-white placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-primary/50"
            onFocus={() => setSearchOpen(true)}
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
      </div>
      
      {/* Chat List */}
      <div className="flex-grow overflow-y-auto">
        {chats.length > 0 ? (
          chats.map((chatInfo) => (
            <ChatItem
              key={chatInfo.chat.id}
              chatInfo={chatInfo}
              selected={chatInfo.chat.id === currentChatId}
              onClick={() => handleChatClick(chatInfo.chat.id)}
            />
          ))
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-4 text-center">
            <div className="user-avatar w-16 h-16 mb-4">
              <span className="text-xl">D</span>
            </div>
            <p className="text-white mb-2">Нет активных чатов</p>
            <p className="text-gray-400 text-sm">
              Нажмите кнопку нового чата, чтобы начать общение
            </p>
          </div>
        )}
      </div>
      
      {/* New Chat Button */}
      <div className="p-4 flex justify-end">
        <button 
          onClick={() => setSearchOpen(true)}
          className="w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors"
        >
          <Plus className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default ChatList;
