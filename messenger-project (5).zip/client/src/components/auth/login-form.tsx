import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Mail, Lock } from "lucide-react";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { APP_NAME } from "@/lib/constants";

interface LoginFormProps {
  onRegisterClick: () => void;
}

const loginSchema = z.object({
  email: z.string().email("Необходимо указать корректный email"),
  password: z.string().min(1, "Необходимо указать пароль"),
});

type LoginFormData = z.infer<typeof loginSchema>;

const LoginForm: React.FC<LoginFormProps> = ({ onRegisterClick }) => {
  const { loginMutation } = useAuth();
  
  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });
  
  const onSubmit = async (data: LoginFormData) => {
    await loginMutation.mutateAsync(data);
  };
  
  return (
    <div className="w-full">
      <div className="flex justify-center mb-6 md:hidden">
        <div className="user-avatar w-16 h-16">
          <span className="text-2xl">D</span>
        </div>
      </div>
      
      <h1 className="text-2xl font-bold text-center mb-6 text-white md:text-left">
        Вход в {APP_NAME}
      </h1>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input 
                      placeholder="Электронная почта" 
                      {...field} 
                      className="input-field pl-10"
                    />
                  </div>
                </FormControl>
                <FormMessage className="text-red-400 text-sm" />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input 
                      type="password" 
                      placeholder="Пароль" 
                      {...field} 
                      className="input-field pl-10"
                    />
                  </div>
                </FormControl>
                <FormMessage className="text-red-400 text-sm" />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            disabled={loginMutation.isPending}
            className="w-full py-5 font-medium"
          >
            {loginMutation.isPending ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              "Войти"
            )}
          </Button>
          
          <div className="text-center pt-2">
            <p className="text-gray-400 mb-2">Еще нет аккаунта?</p>
            <button 
              type="button" 
              onClick={onRegisterClick}
              className="text-primary hover:underline"
            >
              Создать новый аккаунт
            </button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default LoginForm;
