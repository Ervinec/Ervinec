import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { registerStep2Schema, RegisterStep2 } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, User, AtSign, ArrowLeft } from "lucide-react";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface RegisterStep2FormProps {
  onBackClick: () => void;
}

const RegisterStep2Form: React.FC<RegisterStep2FormProps> = ({ onBackClick }) => {
  const { registerStep2Mutation } = useAuth();
  
  const form = useForm<RegisterStep2>({
    resolver: zodResolver(registerStep2Schema),
    defaultValues: {
      displayName: "",
      username: "",
    },
  });
  
  const onSubmit = async (data: RegisterStep2) => {
    try {
      await registerStep2Mutation.mutateAsync(data);
    } catch (error) {
      console.error("Registration step 2 error:", error);
    }
  };
  
  return (
    <div className="w-full">
      <div className="flex justify-center mb-6 md:hidden">
        <div className="user-avatar w-16 h-16">
          <span className="text-2xl">T</span>
        </div>
      </div>
      
      <h1 className="text-2xl font-bold text-center mb-2 text-white md:text-left">
        Почти готово!
      </h1>
      <p className="text-center md:text-left text-gray-400 mb-6">
        Укажите ваше имя и имя пользователя для завершения регистрации
      </p>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            control={form.control}
            name="displayName"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input 
                      placeholder="Ваше имя" 
                      {...field} 
                      className="input-field pl-10"
                    />
                  </div>
                </FormControl>
                <FormMessage className="text-red-400 text-sm" />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="relative">
                    <AtSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input 
                      placeholder="Имя пользователя" 
                      {...field} 
                      className="input-field pl-10"
                    />
                  </div>
                </FormControl>
                <FormMessage className="text-red-400 text-sm" />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            disabled={registerStep2Mutation.isPending}
            className="w-full py-5 font-medium"
          >
            {registerStep2Mutation.isPending ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              "Создать аккаунт"
            )}
          </Button>
          
          <div className="text-center pt-2">
            <button 
              type="button" 
              onClick={onBackClick}
              className="text-primary hover:underline inline-flex items-center"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Вернуться к предыдущему шагу
            </button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default RegisterStep2Form;
