import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { registerStep1Schema, RegisterStep1 } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Mail, Lock } from "lucide-react";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { APP_NAME } from "@/lib/constants";

interface RegisterStep1FormProps {
  onLoginClick: () => void;
  onSuccessfulSubmit: () => void;
}

const RegisterStep1Form: React.FC<RegisterStep1FormProps> = ({ onLoginClick, onSuccessfulSubmit }) => {
  const { registerStep1Mutation } = useAuth();
  
  const form = useForm<RegisterStep1>({
    resolver: zodResolver(registerStep1Schema),
    defaultValues: {
      email: "",
      password: "",
    },
  });
  
  const onSubmit = async (data: RegisterStep1) => {
    try {
      await registerStep1Mutation.mutateAsync(data);
      onSuccessfulSubmit();
    } catch (error) {
      console.error("Registration step 1 error:", error);
    }
  };
  
  return (
    <div className="w-full">
      <div className="flex justify-center mb-6 md:hidden">
        <div className="user-avatar w-16 h-16">
          <span className="text-2xl">D</span>
        </div>
      </div>
      
      <h1 className="text-2xl font-bold text-center mb-6 text-white md:text-left">
        Создание аккаунта
      </h1>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input 
                      placeholder="Электронная почта" 
                      {...field} 
                      className="input-field pl-10"
                    />
                  </div>
                </FormControl>
                <FormMessage className="text-red-400 text-sm" />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input 
                      type="password" 
                      placeholder="Пароль" 
                      {...field} 
                      className="input-field pl-10"
                    />
                  </div>
                </FormControl>
                <FormMessage className="text-red-400 text-sm" />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            disabled={registerStep1Mutation.isPending}
            className="w-full py-5 font-medium"
          >
            {registerStep1Mutation.isPending ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              "Продолжить"
            )}
          </Button>
          
          <div className="text-center pt-2">
            <p className="text-gray-400 mb-2">Уже есть аккаунт?</p>
            <button 
              type="button" 
              onClick={onLoginClick}
              className="text-primary hover:underline"
            >
              Войти в {APP_NAME}
            </button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default RegisterStep1Form;
