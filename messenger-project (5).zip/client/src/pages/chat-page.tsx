import React, { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { ChatProvider } from "@/hooks/use-chat";
import { useMobile } from "@/hooks/use-mobile";
import ChatList from "@/components/chat/chat-list";
import ChatWindow from "@/components/chat/chat-window";

const ChatPage: React.FC = () => {
  const { user } = useAuth();
  const isMobile = useMobile();
  const [showChatList, setShowChatList] = useState(true);
  
  if (!user) return null;
  
  return (
    <ChatProvider>
      <div className="h-screen flex flex-col md:flex-row overflow-hidden telegram-bg-gradient">
        {(!isMobile || showChatList) && (
          <div className="w-full md:w-1/3 md:max-w-xs h-full telegram-sidebar">
            <ChatList onChatSelect={() => setShowChatList(false)} />
          </div>
        )}
        
        {(!isMobile || !showChatList) && (
          <div className="flex-grow h-full telegram-chat-bg">
            <ChatWindow 
              onBackToChats={() => setShowChatList(true)} 
              isMobile={isMobile}
            />
          </div>
        )}
      </div>
    </ChatProvider>
  );
};

export default ChatPage;
