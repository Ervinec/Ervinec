import React, { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ChevronLeft, User as UserIcon, Mail, AtSign, Save, Edit, MessageSquare } from "lucide-react";
import { getAvatarColor, getInitials } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useChat } from "@/hooks/use-chat";
import { User } from "@shared/schema";

const profileSchema = z.object({
  displayName: z.string().min(2, "Имя должно содержать минимум 2 символа"),
  bio: z.string().max(200, "Био должно быть не более 200 символов"),
});

type ProfileData = z.infer<typeof profileSchema>;

const ProfilePage: React.FC = () => {
  const { id: profileId } = useParams();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { createChat } = useChat();
  const [isEditing, setIsEditing] = useState(false);

  // Check if viewing own profile
  const isOwnProfile = !profileId || (user && parseInt(profileId) === user.id);

  // Fetch profile data
  const { data: profileUser, isLoading } = useQuery<User>({
    queryKey: [`/api/users/${isOwnProfile ? user?.id : profileId}`],
    enabled: !!user && (isOwnProfile ? !!user.id : !!profileId),
  });

  // Form setup
  const form = useForm<ProfileData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: profileUser?.displayName || "",
      bio: profileUser?.bio || "",
    },
    values: {
      displayName: profileUser?.displayName || "",
      bio: profileUser?.bio || "",
    },
  });

  // Update form values when profile data changes
  useEffect(() => {
    if (profileUser) {
      form.reset({
        displayName: profileUser.displayName,
        bio: profileUser.bio || "",
      });
    }
  }, [profileUser, form]);

  // Mutation for updating profile
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileData) => {
      const res = await apiRequest("PATCH", `/api/users/${user!.id}`, data);
      return await res.json();
    },
    onSuccess: (updatedUser) => {
      queryClient.setQueryData([`/api/users/${user!.id}`], updatedUser);
      toast({
        title: "Профиль обновлен",
        description: "Ваши изменения были сохранены",
      });
      setIsEditing(false);
    },
    onError: (error) => {
      toast({
        title: "Ошибка",
        description: `Не удалось обновить профиль: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProfileData) => {
    updateProfileMutation.mutate(data);
  };

  // Start a chat with this user
  const startChat = async () => {
    if (!profileId || !user) return;
    
    try {
      const chat = await createChat(parseInt(profileId));
      setLocation(`/`);
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось создать чат",
        variant: "destructive",
      });
    }
  };

  if (!user) {
    setLocation("/auth");
    return null;
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-[#17212B] to-[#0E1621]">
      {/* Header */}
      <div className="flex items-center p-4 bg-[#17212B]/80 backdrop-blur-sm border-b border-[#151F28]">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setLocation("/")} 
          className="text-white hover:bg-[#232E3C]"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h1 className="ml-4 text-xl font-medium text-white">
          {isOwnProfile ? "Мой профиль" : "Профиль пользователя"}
        </h1>
      </div>

      {/* Content */}
      <div className="flex-grow p-4 md:p-6 max-w-2xl mx-auto w-full">
        {isLoading ? (
          <div className="space-y-6">
            <div className="flex flex-col items-center">
              <Skeleton className="w-24 h-24 rounded-full" />
              <Skeleton className="h-8 w-40 mt-4" />
            </div>
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : profileUser ? (
          <>
            {/* Profile Avatar */}
            <div className="flex flex-col items-center mb-8">
              <div 
                className="w-24 h-24 rounded-full flex items-center justify-center text-white text-3xl user-avatar"
                style={{ backgroundColor: getAvatarColor(profileUser.id) }}
              >
                {getInitials(profileUser.displayName)}
              </div>
              <h2 className="mt-4 text-2xl font-bold text-white">{profileUser.displayName}</h2>
              <p className="text-gray-400">@{profileUser.username}</p>
            </div>

            {isOwnProfile && isEditing ? (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="displayName"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center space-x-4 bg-[#242F3D] p-3 rounded-lg mb-1">
                          <UserIcon className="h-5 w-5 text-gray-400" />
                          <FormControl>
                            <Input
                              placeholder="Ваше имя"
                              className="border-none bg-transparent text-white focus-visible:ring-0 p-0 placeholder:text-gray-500"
                              {...field}
                            />
                          </FormControl>
                        </div>
                        <FormMessage className="text-red-400 text-sm" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="bio"
                    render={({ field }) => (
                      <FormItem>
                        <div className="bg-[#242F3D] p-3 rounded-lg mb-1">
                          <FormControl>
                            <Textarea
                              placeholder="О себе (необязательно)"
                              className="border-none bg-transparent text-white resize-none min-h-[120px] focus-visible:ring-0 p-0 placeholder:text-gray-500"
                              {...field}
                            />
                          </FormControl>
                        </div>
                        <FormMessage className="text-red-400 text-sm" />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end space-x-3">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setIsEditing(false)}
                    >
                      Отмена
                    </Button>
                    <Button
                      type="submit"
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? "Сохранение..." : "Сохранить"}
                    </Button>
                  </div>
                </form>
              </Form>
            ) : (
              <div className="space-y-6">
                {/* Email */}
                <div className="flex items-center space-x-4 bg-[#242F3D] p-4 rounded-lg">
                  <Mail className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-gray-400 text-sm">Почта</p>
                    <p className="text-white">{profileUser.email}</p>
                  </div>
                </div>

                {/* Username */}
                <div className="flex items-center space-x-4 bg-[#242F3D] p-4 rounded-lg">
                  <AtSign className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-gray-400 text-sm">Имя пользователя</p>
                    <p className="text-white">@{profileUser.username}</p>
                  </div>
                </div>

                {/* Bio */}
                <div className="bg-[#242F3D] p-4 rounded-lg">
                  <p className="text-gray-400 text-sm mb-2">О себе</p>
                  <p className="text-white">
                    {profileUser.bio ? profileUser.bio : <span className="text-gray-500">Не указано</span>}
                  </p>
                </div>

                {/* Action buttons */}
                <div className="flex justify-end space-x-3 mt-6">
                  {isOwnProfile ? (
                    <Button
                      onClick={() => setIsEditing(true)}
                      className="flex items-center"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Редактировать
                    </Button>
                  ) : (
                    <Button
                      onClick={startChat}
                      className="flex items-center"
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Написать сообщение
                    </Button>
                  )}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-10">
            <p className="text-white text-xl">Пользователь не найден</p>
            <Button 
              onClick={() => setLocation("/")} 
              className="mt-4"
            >
              Вернуться к чатам
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;