import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import LoginForm from "@/components/auth/login-form";
import RegisterStep1Form from "@/components/auth/register-step1-form";
import RegisterStep2Form from "@/components/auth/register-step2-form";
import { APP_NAME, APP_SLOGAN } from "@/lib/constants";

type AuthScreens = "login" | "register-step1" | "register-step2";

const AuthPage: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<AuthScreens>("login");
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  
  // Redirect to chat if already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);
  
  const handleLoginClick = () => setCurrentScreen("login");
  const handleRegisterClick = () => setCurrentScreen("register-step1");
  const handleStep1Success = () => setCurrentScreen("register-step2");
  const handleBackToStep1 = () => setCurrentScreen("register-step1");
  
  return (
    <div className="auth-container">
      <div className="grid md:grid-cols-2 gap-8 w-full max-w-5xl">
        {/* Left side: Hero / Branding */}
        <div className="hidden md:flex flex-col justify-center items-center text-center p-8">
          <div className="space-y-6">
            <div className="user-avatar w-24 h-24 mx-auto mb-4">
              <span className="text-3xl">D</span>
            </div>
            <h1 className="text-4xl font-bold text-white">{APP_NAME}</h1>
            <p className="text-lg text-gray-300">
              {APP_SLOGAN}
            </p>
            <div className="pt-6">
              <ul className="space-y-4 text-gray-300">
                <li className="flex items-center">
                  <span className="mr-2">✓</span>
                  <span>Быстрые сообщения</span>
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span>
                  <span>Групповые чаты</span>
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span>
                  <span>Поиск пользователей</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Right side: Auth forms */}
        <div className="auth-card md:max-w-md">
          {currentScreen === "login" && (
            <LoginForm onRegisterClick={handleRegisterClick} />
          )}
          
          {currentScreen === "register-step1" && (
            <RegisterStep1Form 
              onLoginClick={handleLoginClick}
              onSuccessfulSubmit={handleStep1Success}
            />
          )}
          
          {currentScreen === "register-step2" && (
            <RegisterStep2Form onBackClick={handleBackToStep1} />
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
