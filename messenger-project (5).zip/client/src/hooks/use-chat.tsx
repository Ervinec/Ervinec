import { createContext, ReactNode, useContext, useEffect, useState, useRef } from "react";
import { useAuth } from "./use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Chat, Message, User } from "@shared/schema";
import { useToast } from "./use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatTime } from "@/lib/constants";

// Types
export type ChatWithParticipants = {
  chat: Chat;
  lastMessage?: Message;
  unreadCount?: number;
  participants: Omit<User, "password">[];
};

interface WebSocketMessage {
  type: string;
  payload: any;
}

type ChatContextType = {
  chats: ChatWithParticipants[];
  currentChatId: number | null;
  messages: Message[];
  isLoadingChats: boolean;
  isLoadingMessages: boolean;
  sendMessage: (content: string) => void;
  createChat: (userId: number) => Promise<Chat>;
  selectChat: (chatId: number) => void;
  searchUsers: (query: string) => Promise<Omit<User, "password">[]>;
  typingUsers: Record<number, string[]>;
  startTyping: () => void;
  stopTyping: () => void;
};

export const ChatContext = createContext<ChatContextType | null>(null);

export function ChatProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentChatId, setCurrentChatId] = useState<number | null>(null);
  const [typingUsers, setTypingUsers] = useState<Record<number, string[]>>({});
  const socketRef = useRef<WebSocket | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // WebSocket setup
  useEffect(() => {
    if (!user) return;
    
    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = new WebSocket(`${wsProtocol}//${window.location.host}/ws?userId=${user.id}`);
    
    socket.onopen = () => {
      console.log('WebSocket connected');
    };
    
    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data) as WebSocketMessage;
        
        switch (data.type) {
          case 'new_message':
            const message = data.payload as Message;
            
            // Update messages if this is the current chat
            if (message.chatId === currentChatId) {
              queryClient.setQueryData(
                [`/api/chats/${message.chatId}/messages`],
                (oldMessages: Message[] = []) => [...oldMessages, message]
              );
            }
            
            // Update chat list to show latest message
            queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
            break;
            
          case 'typing':
            handleTypingEvent(data.payload);
            break;
            
          case 'error':
            console.error('WebSocket error:', data.payload.message);
            break;
            
          default:
            console.log('Unknown WebSocket message type:', data.type);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    socket.onclose = () => {
      console.log('WebSocket disconnected');
    };
    
    socketRef.current = socket;
    
    // Cleanup
    return () => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, [user, currentChatId, queryClient]);

  // Handle typing events
  const handleTypingEvent = (payload: { chatId: number; userId: number; isTyping: boolean }) => {
    const { chatId, userId, isTyping } = payload;
    
    setTypingUsers((prev) => {
      const users = prev[chatId] || [];
      const user = queryClient.getQueryData<ChatWithParticipants[]>(['/api/chats'])
        ?.flatMap(c => c.participants)
        .find(p => p.id === userId);
      
      if (!user) return prev;
      
      if (isTyping && !users.includes(user.displayName)) {
        return {
          ...prev,
          [chatId]: [...users, user.displayName]
        };
      } else if (!isTyping) {
        return {
          ...prev,
          [chatId]: users.filter(name => name !== user.displayName)
        };
      }
      
      return prev;
    });
  };

  // Fetch chats
  const { data: chats = [], isLoading: isLoadingChats } = useQuery<ChatWithParticipants[]>({
    queryKey: ['/api/chats'],
    enabled: !!user,
  });

  // Fetch messages for current chat
  const { data: messages = [], isLoading: isLoadingMessages } = useQuery<Message[]>({
    queryKey: [`/api/chats/${currentChatId}/messages`],
    enabled: !!currentChatId,
  });

  // Select a chat
  const selectChat = (chatId: number) => {
    setCurrentChatId(chatId);
  };

  // Send a message
  const sendMessage = (content: string) => {
  if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
    console.log("WebSocket not connected, message not sent");
    return;
  }
    if (!content.trim() || !currentChatId || !user) return;
    
    // Stop typing indicator
    stopTyping();
    
    // Optimistically update UI
    const tempId = Date.now();
    const tempMessage: Message = {
      id: tempId,
      chatId: currentChatId,
      senderId: user.id,
      content,
      sentAt: new Date(),
    };
    
    queryClient.setQueryData(
      [`/api/chats/${currentChatId}/messages`],
      (oldMessages: Message[] = []) => [...oldMessages, tempMessage]
    );
    
    // Send via WebSocket for real-time delivery
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'message',
        payload: {
          chatId: currentChatId,
          content,
        }
      }));
    } else {
      // Fallback to HTTP if WebSocket is not available
      apiRequest('POST', `/api/chats/${currentChatId}/messages`, { content })
        .then(async (res) => {
          const newMessage = await res.json();
          
          // Replace temp message with actual one
          queryClient.setQueryData(
            [`/api/chats/${currentChatId}/messages`],
            (oldMessages: Message[] = []) => 
              oldMessages.map(msg => msg.id === tempId ? newMessage : msg)
          );
          
          // Update chat list
          queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
        })
        .catch(error => {
          console.error('Error sending message:', error);
          toast({
            title: 'Ошибка отправки',
            description: 'Не удалось отправить сообщение',
            variant: 'destructive',
          });
          
          // Remove temp message on error
          queryClient.setQueryData(
            [`/api/chats/${currentChatId}/messages`],
            (oldMessages: Message[] = []) => 
              oldMessages.filter(msg => msg.id !== tempId)
          );
        });
    }
  };

  // Create a new chat
  const createChatMutation = useMutation<Chat, Error, number>({
    mutationFn: async (userId: number) => {
      const res = await apiRequest('POST', '/api/chats', {
        participantId: userId,
        isGroup: false,
      });
      return await res.json();
    },
    onSuccess: (chat) => {
      queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
      setCurrentChatId(chat.id);
    },
    onError: (error) => {
      toast({
        title: 'Ошибка',
        description: `Не удалось создать чат: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Search users
  const searchUsers = async (query: string): Promise<Omit<User, "password">[]> => {
    if (!query.trim()) return [];
    
    try {
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`, {
        credentials: 'include',
      });
      
      if (!res.ok) {
        throw new Error('Ошибка поиска пользователей');
      }
      
      return await res.json();
    } catch (error) {
      console.error('Error searching users:', error);
      return [];
    }
  };

  // Typing indicator functions
  const startTyping = () => {
    if (!currentChatId || !socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return;
    
    socketRef.current.send(JSON.stringify({
      type: 'typing',
      payload: {
        chatId: currentChatId,
        isTyping: true,
      }
    }));
    
    // Clear previous timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    // Set timeout to stop typing indication after 3 seconds
    typingTimeoutRef.current = setTimeout(stopTyping, 3000);
  };
  
  const stopTyping = () => {
    if (!currentChatId || !socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return;
    
    socketRef.current.send(JSON.stringify({
      type: 'typing',
      payload: {
        chatId: currentChatId,
        isTyping: false,
      }
    }));
    
    // Clear timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = null;
    }
  };

  return (
    <ChatContext.Provider
      value={{
        chats,
        currentChatId,
        messages,
        isLoadingChats,
        isLoadingMessages,
        sendMessage,
        createChat: createChatMutation.mutateAsync,
        selectChat,
        searchUsers,
        typingUsers,
        startTyping,
        stopTyping,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}
