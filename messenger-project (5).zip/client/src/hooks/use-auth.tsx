import { createContext, ReactNode, useContext } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { RegisterStep1, RegisterStep2, User } from "@shared/schema";

type SafeUser = Omit<User, "password">;

type AuthContextType = {
  user: SafeUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<SafeUser, Error, { email: string; password: string }>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerStep1Mutation: UseMutationResult<{ message: string }, Error, RegisterStep1>;
  registerStep2Mutation: UseMutationResult<SafeUser, Error, RegisterStep2>;
};

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<SafeUser>({
    queryKey: ["/api/user"],
    queryFn: async ({ queryKey }) => {
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        
        if (res.status === 401) {
          return null;
        }
        
        if (!res.ok) {
          throw new Error("Ошибка получения данных пользователя");
        }
        
        return await res.json();
      } catch (error) {
        console.error("Error fetching user:", error);
        return null;
      }
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: { email: string; password: string }) => {
      const res = await apiRequest("POST", "/api/login", credentials);
      return await res.json();
    },
    onSuccess: (user: SafeUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Успешный вход",
        description: `Добро пожаловать, ${user.displayName}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка входа",
        description: error.message || "Неверный email или пароль",
        variant: "destructive",
      });
    },
  });

  const registerStep1Mutation = useMutation({
    mutationFn: async (data: RegisterStep1) => {
      const res = await apiRequest("POST", "/api/register/step1", data);
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка при регистрации",
        description: error.message || "Проверьте введенные данные",
        variant: "destructive",
      });
    },
  });

  const registerStep2Mutation = useMutation({
    mutationFn: async (data: RegisterStep2) => {
      const res = await apiRequest("POST", "/api/register/step2", data);
      return await res.json();
    },
    onSuccess: (user: SafeUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Регистрация завершена",
        description: `Добро пожаловать, ${user.displayName}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка при регистрации",
        description: error.message || "Проверьте введенные данные",
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      queryClient.invalidateQueries();
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка при выходе",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerStep1Mutation,
        registerStep2Mutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
